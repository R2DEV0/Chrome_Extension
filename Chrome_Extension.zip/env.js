window.env = {
    AUTH0_DOMAIN: "dcapjtayloreducation.us.auth0.com",
    AUTH0_CLIENT_ID: "VaILxRTc55VGhDLD3i04fKz7du4QYcRj",
};