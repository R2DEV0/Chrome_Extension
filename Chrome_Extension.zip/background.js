chrome.runtime.onMessage.addListener(function (event) {
    
    if (event.type === 'authenticate') {
        var Auth0 = new Auth0Chrome(env.AUTH0_DOMAIN, env.AUTH0_CLIENT_ID);
        var options = {
            scope: 'openid',
            device: 'chrome-extension'
        };
        Auth0.authenticate(options)
            .then(function (authResult) {
                localStorage.authResult = JSON.stringify(authResult);
                console.log("logged in!");
                chrome.runtime.sendMessage({
                user: "logged in"
                });
            })
            .catch(function (err) {
                console.log("not logged in");
            });
    }
});